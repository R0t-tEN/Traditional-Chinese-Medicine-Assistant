1. 核心配置文件 (herb_project/herb_project/settings.py)
这个文件是所有日志和异常功能的总开关和配置中心。

# herb_project/herb_project/settings.py

# ... (其他设置) ...
import os

# --- 1. 框架层面的异常处理开关 ---
# 在本地开发时，DEBUG=True 可以在发生未捕获的错误时，显示包含详细信息的黄色调试页面。
# 在部署到生产服务器时，必须设为 False。
DEBUG = True

# ... (其他设置) ...

# --- 2. 完整的日志系统配置 ---
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'simple': {
            'format': '{levelname} {asctime} {module}: {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
            'formatter': 'simple'
        },
        'file': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(BASE_DIR, 'logs', 'herb_project.log'),
            'maxBytes': 1024 * 1024 * 5,
            'backupCount': 5,
            'formatter': 'simple'
        },
    },
    'loggers': {
        'django': {
            'handlers': ['console', 'file'],
            'level': 'INFO',
            'propagate': True,
        },
        'recognizer': { # 这是我们自己应用的关键日志记录器
            'handlers': ['console', 'file'],
            'level': 'DEBUG', # 记录所有级别的日志
            'propagate': False,
        },
    }
}

小结: 这个文件定义了规则——日志记什么、怎么记，以及出错时要不要显示详细的调试页。


2. AI 模型加载模块 (herb_project/recognizer/predictor.py)
这个文件负责处理与AI模型自身相关的错误，确保应用在后台启动时是健壮的。

# herb_project/recognizer/predictor.py

import logging
# 获取在 settings.py 中定义的 'recognizer' 日志记录器
logger = logging.getLogger('recognizer')

# ... (其他导入和代码) ...

def load_model():
    """在 Django 启动时加载指定的模型。"""
    global model, class_names

    # ... (前面的检查逻辑，如 if model is not None:) ...
        
    # --- 异常处理核心区：确保模型加载失败时，整个应用不会崩溃 ---
    try:
        # 尝试加载类别文件和模型权重
        logger.info(f"--- 正在加载激活的模型: {ACTIVE_MODEL} ---")
        
        with open(CLASS_NAMES_PATH, 'r', encoding='utf-8') as f:
            class_names = json.load(f)
        
        # ... (创建模型实例，加载权重的代码) ...
        # model_instance.load_state_dict(...)
        
        model = model_instance
        logger.info(f"模型 '{ACTIVE_MODEL}' 加载成功！预测功能已就绪。")
        
    except Exception as e:
        # 如果 try 块中的任何一步失败（如文件没找到、文件损坏等）
        # 都会执行这里的代码。
        
        # 使用 logger.error 记录下这个严重错误。
        # exc_info=True 会自动将完整的错误堆栈信息附加到日志中，非常利于排查问题。
        logger.error(f"加载模型 '{ACTIVE_MODEL}' 时发生严重错误!", exc_info=True)
        
        # 将 model 设为 None，这是一个关键的“保险丝”。
        # 后续的预测函数会通过检查 model 是否为 None，来判断模型是否可用。
        model = None


def predict_herb(input_image: Image.Image):
    """核心预测函数。"""
    
    # --- 前置检查：如果模型加载失败，直接返回错误，避免程序崩溃 ---
    if model is None:
        active_model_name = ACTIVE_MODEL
        logger.error(f"用户尝试进行预测，但模型 '{active_model_name}' 未能成功加载。")
        return {"error": f"模型 '{active_model_name}' 未能成功加载。请先训练该模型并重启服务。"}
        
    # ... (后续的正常预测逻辑) ...

小结: 这个文件在后台服务层面处理异常，确保核心功能即使有问题，也不会拖垮整个网站。




3. Web 请求处理模块 (herb_project/recognizer/views.py)
这个文件负责处理与用户交互相关的错误，比如用户上传了无效的文件，确保网站能给用户一个友好的反馈。

# herb_project/recognizer/views.py

from django.shortcuts import render
from PIL import Image
from .predictor import predict_herb
import base64
from io import BytesIO

# ... (catalog_view 视图代码) ...

def recognize_view(request):
    context = {'result': None}
    
    if request.method == 'POST' and request.FILES.get('image'):
        image_file = request.FILES.get('image')
        
        # --- 异常处理核心区：确保用户的不当操作不会导致服务器崩溃 ---
        try:
            # 这一步可能会失败，比如用户上传的不是图片文件，或者文件已损坏。
            input_image = Image.open(image_file)
            
            # 调用预测函数
            prediction_result = predict_herb(input_image)
            context['result'] = prediction_result
            
            # 将上传的图片编码后传回前端显示
            buffered = BytesIO()
            save_format = 'PNG' if input_image.mode == 'RGBA' else 'JPEG'
            input_image.save(buffered, format=save_format)
            img_str = base64.b64encode(buffered.getvalue()).decode()
            context['uploaded_image'] = f"data:image/{save_format.lower()};base64,{img_str}"

        except Exception as e:
            # 如果 try 块中任何一步出错，程序不会崩溃，而是会执行这里。
            
            # 我们捕获这个通用的 Exception，并将其信息友好地展示给用户。
            # 这比让用户看到一个通用的“服务器错误”页面要好得多。
            context['result'] = {"error": f"处理图片时出错: {e}"}

            # (可选，但推荐) 也可以在这里记录一次警告日志，说明有用户进行了错误操作。
            # import logging
            # logger = logging.getLogger('recognizer')
            # logger.warning(f"处理用户上传的文件时发生错误: {e}", exc_info=False)

    return render(request, 'recognizer/recognize.html', context)

小结: 这个文件在用户交互层面处理异常，确保网站的用户体验是健壮和友好的。