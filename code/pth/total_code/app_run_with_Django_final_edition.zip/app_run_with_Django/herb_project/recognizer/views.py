# herb_project/recognizer/views.py

from django.shortcuts import render, redirect
from django.urls import reverse
from PIL import Image
from .predictor import predict_herb
import base64
from io import BytesIO
# --- 关键修复：在这里同时导入 Herb 和 GameImage ---
from .models import Herb, GameImage 
from django.db.models import Q
import os
import random
from django.conf import settings

# 因为我们已经不再从 static 文件夹读取游戏图片，
# 所以下面这几行关于 GAME_IMAGE_DIR 和 GAME_IMAGES 的代码可以安全地删除了。
# GAME_IMAGE_DIR = os.path.join(settings.BASE_DIR, 'static', 'game_images')
# GAME_IMAGES = []
# if os.path.exists(GAME_IMAGE_DIR):
#     GAME_IMAGES = [f for f in os.listdir(GAME_IMAGE_DIR) if os.path.isfile(os.path.join(GAME_IMAGE_DIR, f))]
# else:
#     print(f"警告：游戏图片目录 '{GAME_IMAGE_DIR}' 不存在。游戏功能将不可用。")


def catalog_view(request):
    query = request.GET.get('q', '')
    if query:
        herbs = Herb.objects.filter(Q(chinese_name__icontains=query) | Q(pinyin_name__icontains=query)).order_by('pinyin_name')
    else:
        herbs = Herb.objects.all().order_by('pinyin_name')
    context = {'herbs': herbs, 'herbs_count': herbs.count(), 'query': query}
    return render(request, 'recognizer/catalog.html', context)

def recognize_view(request):
    context = {'result': None}
    if request.method == 'POST' and request.FILES.get('image'):
        image_file = request.FILES['image']
        try:
            input_image = Image.open(image_file)
            prediction_result = predict_herb(input_image)
            context['result'] = prediction_result
            buffered = BytesIO()
            save_format = 'PNG' if input_image.mode == 'RGBA' else 'JPEG'
            input_image.save(buffered, format=save_format)
            img_str = base64.b64encode(buffered.getvalue()).decode()
            context['uploaded_image'] = f"data:image/{save_format.lower()};base64,{img_str}"
        except Exception as e:
            context['result'] = {"error": f"处理图片时出错: {e}"}
    return render(request, 'recognizer/recognize.html', context)


def game_view(request):
    """处理“看图猜药材”游戏的逻辑"""
    
    correct_count = request.session.get('correct_count', 0)
    incorrect_count = request.session.get('incorrect_count', 0)
    
    context = {}

    if request.method == 'POST':
        user_answer = request.POST.get('answer', '').strip()
        correct_answer = request.session.get('current_answer', '')
        
        if user_answer and correct_answer:
            if user_answer == correct_answer:
                feedback = "答对了！"
                feedback_type = "correct"
                correct_count += 1
            else:
                feedback = f"答错了，正确答案是：{correct_answer}"
                feedback_type = "incorrect"
                incorrect_count += 1
            
            context['feedback'] = feedback
            context['feedback_type'] = feedback_type
        
        request.session['correct_count'] = correct_count
        request.session['incorrect_count'] = incorrect_count

    # 现在因为 GameImage 已经被导入，所以这一行可以正常工作了
    all_game_images = GameImage.objects.all()
    
    if all_game_images.exists():
        current_game_image = random.choice(all_game_images)
        current_answer = current_game_image.herb.chinese_name
        current_image_url = current_game_image.image.url
        
        request.session['current_answer'] = current_answer
        context['current_image_url'] = current_image_url
    else:
        context['error_message'] = "游戏题库为空，请先在 Admin 后台添加游戏图片。"

    total_attempts = correct_count + incorrect_count
    accuracy = (correct_count / total_attempts * 100) if total_attempts > 0 else 0
    
    context.update({
        'correct_count': correct_count,
        'incorrect_count': incorrect_count,
        'total_attempts': total_attempts,
        'accuracy': f"{accuracy:.1f}%",
    })

    return render(request, 'recognizer/game.html', context)


def reset_game_view(request):
    """重置游戏分数和状态"""
    request.session['correct_count'] = 0
    request.session['incorrect_count'] = 0
    return redirect(reverse('game'))