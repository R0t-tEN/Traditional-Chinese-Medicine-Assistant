# herb_project/recognizer/admin.py

from django.contrib import admin
# --- 关键修复：在这里同时导入 Herb 和 GameImage ---
from .models import Herb, GameImage 

@admin.register(Herb)
class HerbAdmin(admin.ModelAdmin):
    list_display = ('pinyin_name', 'chinese_name')
    search_fields = ('pinyin_name', 'chinese_name')

# 现在，因为 GameImage 已经被导入了，所以 Django 认识它了
@admin.register(GameImage)
class GameImageAdmin(admin.ModelAdmin):
    # 在列表页显示关联的药材和图片
    list_display = ('herb', 'image')
    # 允许按药材名称搜索
    search_fields = ('herb__chinese_name',)
    # 在右侧添加一个过滤器，可以按药材筛选
    list_filter = ('herb',)