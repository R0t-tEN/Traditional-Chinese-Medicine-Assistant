# herb_project/recognizer/models.py

from django.db import models

class Herb(models.Model):
    """定义中草药的数据模型"""
    
    # 使用拼音作为主键，因为它在项目中是唯一的，并且方便查询
    pinyin_name = models.CharField(
        max_length=100, 
        primary_key=True, 
        verbose_name="拼音名称"
    )
    
    chinese_name = models.CharField(
        max_length=100, 
        verbose_name="中文名称"
    )
    
    description = models.TextField(
        verbose_name="药材介绍",
        help_text="请输入关于此药材的详细介绍、功效等信息。"
    )
    
    # 存储示例图片。图片将被上传到 MEDIA_ROOT/herb_images/ 目录下
    image = models.ImageField(
        upload_to='herb_images/',
        verbose_name="示例图片"
    )

    class Meta:
        verbose_name = "中草药"
        verbose_name_plural = "中草药"

    def __str__(self):
        return self.chinese_name
    


class GameImage(models.Model):
    """定义“看图猜药材”游戏的图片数据模型"""
    
    # 使用外键关联到 Herb 模型
    # on_delete=models.CASCADE 表示如果对应的药材被删除，这张游戏图片也会被一并删除
    herb = models.ForeignKey(
        Herb, 
        on_delete=models.CASCADE,
        verbose_name="关联药材"
    )
    
    # 游戏图片字段，上传到 'game_images/' 目录
    image = models.ImageField(
        upload_to='game_images/',
        verbose_name="游戏图片"
    )

    class Meta:
        verbose_name = "游戏图片"
        verbose_name_plural = "游戏图片"

    def __str__(self):
        # 在后台显示时，能清晰地看到这张图片属于哪种药材
        return f"{self.herb.chinese_name} 的游戏图片 (ID: {self.id})"