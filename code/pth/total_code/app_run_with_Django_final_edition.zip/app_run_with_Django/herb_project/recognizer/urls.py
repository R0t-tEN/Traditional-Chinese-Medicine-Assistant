# herb_project/recognizer/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # 将根URL指向新的目录视图
    path('', views.catalog_view, name='catalog'), 
    # 为识别页面创建一个新的URL
    path('recognize/', views.recognize_view, name='recognize'),
    path('game/', views.game_view, name='game'),
    path('game/reset/', views.reset_game_view, name='reset_game'),
]