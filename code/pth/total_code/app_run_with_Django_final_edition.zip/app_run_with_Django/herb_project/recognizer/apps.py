# herb_project/recognizer/apps.py

from django.apps import AppConfig
import logging # 1. 导入 logging 模块

# 2. 获取我们自己定义的 'recognizer' 记录器
logger = logging.getLogger('recognizer')

class RecognizerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'recognizer'

    def ready(self):
        # 3. 将 print 换成 logger.info
        logger.info("正在初始化PyTorch模型 (由 RecognizerConfig.ready() 触发)...")
        from . import predictor
        predictor.load_model()