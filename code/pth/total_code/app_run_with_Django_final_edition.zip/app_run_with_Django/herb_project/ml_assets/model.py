# model.py

import torch.nn as nn
from torchvision import models

def create_resnet18_model(num_classes, use_pretrained=True):
    """
    创建并配置一个ResNet-18模型。

    Args:
        num_classes (int): 输出类别的数量。
        use_pretrained (bool): 是否加载在ImageNet上预训练的权重。
                               训练时应为True，推理时加载自己的权重则为False。
    
    Returns:
        torch.nn.Module: 配置好的ResNet-18模型。
    """
    if use_pretrained:
        weights = models.ResNet18_Weights.IMAGENET1K_V1
    else:
        weights = None
        
    model = models.resnet18(weights=weights)
    
    # 获取全连接层的输入特征数
    num_ftrs = model.fc.in_features
    
    # 替换为我们自己的全连接层
    model.fc = nn.Linear(num_ftrs, num_classes)
    
    return model

def create_densenet121_model(num_classes, use_pretrained=True):
    """
    创建并配置一个 DenseNet-121 模型。
    """
    if use_pretrained:
        # 使用推荐的预训练权重
        weights = models.DenseNet121_Weights.IMAGENET1K_V1
    else:
        weights = None
        
    model = models.densenet121(weights=weights)
    
    # DenseNet的分类器层名为 'classifier'
    num_ftrs = model.classifier.in_features
    
    # 替换为我们自己的全连接层
    model.classifier = nn.Linear(num_ftrs, num_classes)
    
    return model