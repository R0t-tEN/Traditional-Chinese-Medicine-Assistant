# 智能中草药识别项目 (多模型支持版)




## 3. 开发者指南：切换模型

本项目支持在 `ResNet-18` 和 `DenseNet-121` 之间切换。切换操作对最终用户透明，由开发者在后端完成。

### 步骤 3.1: 确保模型已训练

在切换前，请确保你想要使用的模型已经训练完毕。如果对应的模型文件不存在，请先参考 **[章节 4](#4-高级指南重新训练模型)** 进行训练。

### 步骤 3.2: 修改配置文件

1.  打开核心配置文件：
    `herb_project/ml_assets/config.py`

2.  找到 `ACTIVE_MODEL` 变量，将其值修改为你想要的模型名称。
    ```python
    # herb_project/ml_assets/config.py

    # 可选项: 'resnet18', 'densenet121'
    ACTIVE_MODEL = 'densenet121' # <-- 修改这里
    ```

### 步骤 3.3: 重启服务

**重要**：每次修改完配置文件后，都需要**重启 Django 服务器**才能让改动生效。在运行服务器的终端中按 `Ctrl+C` 停止服务，然后重新运行 `python manage.py runserver`。

---

## 4. 高级指南：重新训练模型

你可以使用自己的数据集来训练一个全新的模型，或对现有模型进行微调。

### 步骤 4.1: 准备数据集

1.  在项目根目录 (`total_code/`)下，创建一个名为 `dataset` 的文件夹。
2.  在 `dataset` 文件夹内，创建 `train` 和 `val` 两个子文件夹，分别用于存放训练集和验证集。
3.  在 `train` 和 `val` 文件夹内，为每一种中草药创建一个以其**拼音**命名的文件夹（例如 `gouqizi`, `jinyinhua`）。
4.  将对应类别的图片放入相应的拼音文件夹中。

最终目录结构应如下所示：

```
dataset/
├── train/
│   ├── gouqizi/
│   │   ├── 001.jpg
│   │   └── 002.jpg
│   └── jinyinhua/
│       ├── 001.jpg
│       └── 002.jpg
└── val/
    ├── gouqizi/
    │   ├── 003.jpg
    │   └── 004.jpg
    └── jinyinhua/
        ├── 003.jpg
        └── 004.jpg
```

### 步骤 4.2: 执行训练命令

在项目根目录 (`total_code/`)下，使用 `train.py` 脚本并指定要训练的模型。

-   **训练 ResNet-18**:
    ```bash
    python train.py --model resnet18
    ```

-   **训练 DenseNet-121**:
    ```bash
    python train.py --model densenet121
    ```

训练脚本会自动读取 `dataset` 文件夹中的数据，开始训练。训练完成后，最新的模型文件（如 `resnet18_herb_model.pth`）和类别文件 (`class_names.json`) 将保存在 `herb_project/ml_assets/` 目录下，并覆盖旧文件。

### 步骤 4.3: 加载新模型

训练完成后，请参考 **[章节 3](#3-开发者指南切换模型)** 的步骤来激活并加载你刚刚训练好的新模型。

---

## 5. 项目日志

项目运行期间的所有重要信息（如模型加载、图片识别等）都会被记录下来。

-   **控制台输出**：简化的日志信息会实时显示在运行服务器的终端中。
-   **日志文件**：更详细的日志保存在 `herb_project/logs/herb_project.log` 文件中，方便进行问题排查和分析。




# 如果已经有了训练好的pth文件，使用方法：
操作步骤
步骤 1: 确定你的 .pth 文件对应的模型架构
这是最重要的一步。你必须知道你这个 .pth 文件是用哪种模型训练的。
它是用 ResNet-18 训练的吗？
还是用 DenseNet-121 训练的？
如果把 ResNet-18 的权重加载到一个 DenseNet-121 的模型结构里（反之亦然），程序会因为网络层结构不匹配而立即报错崩溃。
步骤 2: 重命名并放置 .pth 文件
根据你在步骤 1 中确定的模型架构，将你的 .pth 文件重命名为项目约定的名称，并把它放到正确的文件夹里。
目标文件夹: herb_project/ml_assets/
如果你的模型是 ResNet-18:
将你的 .pth 文件（例如叫 my_final_model.pth）重命名为 resnet18_herb_model.pth。
如果你的模型是 DenseNet-121:
将你的 .pth 文件重命名为 densenet121_herb_model.pth。
然后，将这个重命名后的文件移动或复制到 herb_project/ml_assets/ 文件夹下。
步骤 3: 准备并放置 class_names.json 文件
模型权重文件 (.pth) 自身并不包含类别的名称信息。它只知道输出一个包含163个数字的向量。class_names.json 文件就是用来告诉程序，这163个数字按顺序分别对应哪个中草药（比如 ajiao, aiye...）。
这个 class_names.json 文件必须与你的 .pth 文件在训练时使用的类别和顺序完全匹配！
找到与你的 .pth 文件配套的 class_names.json 文件。
将这个 class_names.json 文件也移动或复制到 herb_project/ml_assets/ 文件夹下。
如果你没有 class_names.json 文件怎么办？
你必须根据你当初训练该 .pth 文件时所用的数据集来重新生成它。你可以使用我们之前讨论过的 generate_classes.py 脚本，将它指向你原来的数据集文件夹，来生成一个与训练时顺序一致的 class_names.json 文件。
步骤 4: 修改配置文件以激活模型
现在，文件已经各就各位了，最后一步是告诉 Django 应用去加载它们。
打开配置文件：herb_project/ml_assets/config.py
找到 ACTIVE_MODEL 变量。
根据你在步骤 1 和 2 中准备的文件，修改它的值。
如果你准备的是 resnet18_herb_model.pth，就设置为:
Generated python
ACTIVE_MODEL = 'resnet18'

如果你准备的是 densenet121_herb_model.pth，就设置为:
Generated python
ACTIVE_MODEL = 'densenet121'

步骤 5: 启动应用
所有配置都已完成！现在你可以像普通用户一样启动 Web 应用了。
进入 herb_project 目录：
Generated bash
cd herb_project

启动服务器：
Generated bash
python manage.py runserver

服务器启动时，它会读取 config.py，发现 ACTIVE_MODEL 被设置了，然后就会去 ml_assets 文件夹加载你刚刚放进去的 .pth 文件和 class_names.json 文件。
