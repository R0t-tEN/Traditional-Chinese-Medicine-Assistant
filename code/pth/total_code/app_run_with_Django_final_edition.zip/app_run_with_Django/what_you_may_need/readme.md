如果有训练好的pth，想直接使用，那么请将这个class_names_json和训练好的pth放入
herb_project/ml_assets中，注意！！！训练好的pth文件请命名为t_out_model.pth！！！


total_code/
├── herb_project/                   # Django项目的主文件夹
│   ├── db.sqlite3                  # Django默认的SQLite数据库文件
│   ├── logs/                       # 存放日志文件的文件夹
│   │   └── herb_project.log        # (自动生成) 项目的详细日志记录
│   ├── manage.py                   # Django项目的命令行管理工具
│   ├── media/                      # 存放用户上传的媒体文件
│   │   └── herb_images/            # (自动生成) 存放药材目录的示例图片
│   │       ├── gouqizi.jpg         # (示例) 管理员上传的图片
│   │       └── jinyinhua.png       # (示例) ...
│   ├── ml_assets/                  # 存放所有AI模型相关文件的核心文件夹
│   │   ├── __init__.py             #
│   │   ├── config.py               # ✅ 核心配置文件（模型开关、路径、超参数）
│   │   ├── model.py                # ✅ 定义模型结构 (ResNet-18, DenseNet-121)
│   │   ├── resnet18_herb_model.pth # (训练后生成) ResNet-18的模型权重
│   │   ├── densenet121_herb_model.pth # (训练后生成) DenseNet-121的模型权重
│   │   └── class_names.json        # (训练后生成) 与模型匹配的类别名称列表
│   │
│   ├── herb_project/               # Django项目的配置文件夹
│   │   ├── __init__.py             #
│   │   ├── asgi.py                 # ASGI服务器配置文件
│   │   ├── settings.py             # ✅ Django项目的主设置（含数据库、日志、媒体文件配置）
│   │   ├── urls.py                 # ✅ 项目的主URL路由配置
│   │   └── wsgi.py                 # WSGI服务器配置文件
│   │
│   └── recognizer/                 # 我们创建的核心应用 (App)
│       ├── __init__.py             #
│       ├── admin.py                # ✅ 配置Django Admin后台如何显示模型
│       ├── apps.py                 # ✅ 应用的配置（用于启动时加载模型）
│       ├── models.py               # ✅ 定义数据库结构（如Herb药材模型）
│       ├── predictor.py            # ✅ 封装AI模型加载和预测逻辑的模块
│       ├── tests.py                # 自动化测试文件
│       ├── urls.py                 # ✅ recognizer应用的URL路由配置
│       ├── views.py                # ✅ 处理网页请求的业务逻辑（视图函数）
│       ├── migrations/             # 数据库迁移文件文件夹
│       │   └── 0001_initial.py     # (自动生成) 记录数据库结构的变更
│       │
│       └── templates/              # 存放所有HTML前端页面的文件夹
│           └── recognizer/         #
│               ├── base.html       # ✅ 所有页面的基础模板（含导航栏）
│               ├── catalog.html    # ✅ “药材目录”页面的模板
│               └── recognize.html  # ✅ “智能识别”页面的模板
│
├── dataset/                        # (用户需自行创建) 用于存放训练和验证数据集
│   ├── train/                      #
│   │   └── ...                     #
│   └── val/                        #
│       └── ...                     #
│
├── train.py                        # ✅ 核心训练脚本，用于生成模型文件
├── requirements.txt                # ✅ 项目所有Python依赖库列表
└── README.md                       # ✅ 完整的项目使用手册