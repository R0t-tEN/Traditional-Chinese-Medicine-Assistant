# herb_project/herb_project/urls.py
from django.contrib import admin
from django.urls import path, include
from django.conf import settings # 导入 settings
from django.conf.urls.static import static # 导入 static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('recognizer.urls')),
]

# --- 新增部分：仅在开发模式 (DEBUG=True) 下，让Django能处理媒体文件 ---
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)