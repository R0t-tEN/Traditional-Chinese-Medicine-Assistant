# 百草学堂 - 智能中草药识别与知识库

“百草学堂”是一个基于 PyTorch 和 Django 的现代化中草药学习平台。它不仅提供先进的图像识别功能，还包含一个图文并茂的药材知识库，旨在将传统中医药智慧与现代人工智能技术相结合。

![项目截图](https://user-images.githubusercontent.com/your-username/your-repo/your-screenshot.png)  <!-- 强烈建议：截图后上传到图床或GitHub，然后替换此URL -->

## ✨ 主要特性

-   **药材知识库**：以卡片形式展示已收录的中草药，包含高清图片、名称及功效介绍。
-   **智能识别**：通过上传图片，利用深度学习模型快速识别中草药种类。
-   **后台管理系统**：强大的 Django Admin 后台，让管理员可以轻松添加、编辑和管理药材知识库内容。
-   **多模型支持**：后端支持 `ResNet-18` 和 `DenseNet-121` 等多种模型，开发者可按需配置切换。
-   **可扩展的训练流程**：提供完整的训练脚本，方便开发者使用自定义数据集进行模型训练。
-   **环境友好**：提供 `requirements.txt`，支持一键配置所有依赖项。

---

## 🚀 1. 快速上手指南

本指南将帮助你快速在本地运行“百草学堂”应用。

### 步骤 1.1: 环境配置

在开始之前，请确保你的系统已安装 Python (推荐 3.8+)。我们强烈建议使用虚拟环境。

1.  **创建并激活虚拟环境** (以 `conda` 为例):
    ```bash
    # 创建一个名为 herb_env 的新环境
    conda create -n herb_env python=3.9
    # 激活环境
    conda activate herb_env
    ```

2.  **一键安装所有依赖**:
    在项目根目录下，运行以下命令：
    ```bash
    pip install -r requirements.txt
    ```

### 步骤 1.2: 启动应用

1.  **进入 Django 项目目录**:
    ```bash
    cd herb_project
    ```

2.  **初始化数据库**:
    这是首次运行时必须的步骤，它会创建应用所需的数据库表（包括存储药材信息的表）。
    ```bash
    python manage.py makemigrations
    python manage.py migrate
    ```

3.  **启动 Web 服务器**:
    ```bash
    python manage.py runserver
    ```

4.  **访问应用**:
    当终端显示服务器成功启动后，打开浏览器访问 **`http://127.0.0.1:8000/`**。你将看到“药材目录”页面。点击导航栏即可在“药材目录”和“智能识别”之间切换。

---

## 📚 2. 内容管理：填充药材目录

“药材目录”页面的内容来自数据库。你需要通过 Django Admin 后台来添加和管理这些数据。

### 步骤 2.1: 创建管理员账号

如果你还没有管理员账号，请在终端中运行（确保位于 `herb_project` 目录）:
```bash
python manage.py createsuperuser
```
然后按照提示设置用户名、邮箱和密码。

### 步骤 2.2: 登录后台并添加数据

1.  确保你的 Web 服务器正在运行。
2.  访问后台地址：**`http://127.0.0.1:8000/admin/`**
3.  使用你刚刚创建的管理员账号登录。
4.  在后台主页，找到 "RECOGNIZER" -> "中草药"，点击进入。
5.  点击右上角的“增加 中草药”按钮。
6.  填写表单：
    -   **拼音名称 (Pinyin name)**: 必须与你训练模型时使用的文件夹名称完全一致（例如 `gouqizi`）。这是数据关联的关键。
    -   **中文名称 (Chinese name)**: 将在网页上显示的名称（例如 `枸杞子`）。
    -   **药材介绍 (Description)**: 输入详细的图文介绍。
    -   **示例图片 (Image)**: 上传一张清晰的药材图片。
7.  保存并继续添加，直到你录入完所有希望展示的药材。

---

## 🔧 3. 开发者指南：切换与训练模型

本节面向希望进行二次开发或使用自定义模型的高级用户。

### 步骤 3.1: 切换后端识别模型

你可以轻松切换应用当前使用的 AI 模型。

1.  **打开配置文件**:
    `herb_project/ml_assets/config.py`

2.  **修改 `ACTIVE_MODEL` 变量**:
    将它的值改为你希望激活的模型名称。
    ```python
    # 可选项: 'resnet18', 'densenet121'
    ACTIVE_MODEL = 'densenet121' # <-- 修改这里
    ```

3.  **确认模型文件存在**:
    在切换前，请确保对应的模型文件（如 `densenet121_herb_model.pth`）和 `class_names.json` 都已存在于 `herb_project/ml_assets/` 目录下。如果不存在，请先进行训练。

4.  **重启服务**:
    **重要**：每次修改配置后，都必须重启 Django 服务器 (`Ctrl+C` 后重新 `python manage.py runserver`) 才能加载新模型。

### 步骤 3.2: 重新训练模型

1.  **准备数据集**:
    在项目根目录 (`total_code/`) 下创建 `dataset` 文件夹，并按以下结构组织你的训练和验证图片：
    ```
    dataset/
    ├── train/
    │   ├── gouqizi/
    │   └── ...
    └── val/
        ├── gouqizi/
        └── ...
    ```

2.  **执行训练命令**:
    在项目根目录 (`total_code/`) 下，运行 `train.py` 脚本，并用 `--model` 参数指定架构。
    -   **训练 ResNet-18**:
        ```bash
        python train.py --model resnet18
        ```
    -   **训练 DenseNet-121**:
        ```bash
        python train.py --model densenet121
        ```
    训练完成后，新的模型和 `class_names.json` 文件会自动保存在 `herb_project/ml_assets/` 目录下。

3.  **激活新模型**:
    训练完成后，请参考 **[步骤 3.1](#步骤-31-切换后端识别模型)** 来激活并加载你刚刚训练好的模型。