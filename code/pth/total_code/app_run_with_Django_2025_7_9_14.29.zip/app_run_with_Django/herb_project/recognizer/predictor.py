# herb_project/recognizer/predictor.py

import torch
from PIL import Image
from collections import defaultdict
import json
import sys
import os
import logging

logger = logging.getLogger('recognizer')

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.join(BASE_DIR, 'ml_assets'))

# --- 从 config 导入新变量 ---
from config import DEVICE, CLASS_NAMES_PATH, pinyin_to_chinese, data_transforms
from config import ACTIVE_MODEL, MODEL_PATHS
from model import create_resnet18_model, create_densenet121_model

# --- 恢复为单个模型变量 ---
model = None
class_names = []

def load_model():
    """在 Django 启动时，根据 config 中的 ACTIVE_MODEL 加载指定的模型。"""
    global model, class_names

    if model is not None:
        logger.info("模型已加载，跳过。")
        return

    # 1. 定义模型创建者字典
    model_creators = {
        'resnet18': create_resnet18_model,
        'densenet121': create_densenet121_model
    }

    # 2. 检查 ACTIVE_MODEL 是否有效
    if ACTIVE_MODEL not in model_creators:
        logger.error(f"配置错误: config.py 中的 ACTIVE_MODEL ('{ACTIVE_MODEL}') 是无效的选项。")
        return

    model_path = MODEL_PATHS.get(ACTIVE_MODEL)
    model_creator = model_creators.get(ACTIVE_MODEL)
    
    # 3. 检查模型和类别文件是否存在
    if not model_path or not os.path.exists(model_path):
        logger.warning(f"激活的模型 '{ACTIVE_MODEL}' 的文件未找到，路径: {model_path}。")
        logger.warning("请先运行 'python train.py --model {ACTIVE_MODEL}' 进行训练。")
        return

    if not os.path.exists(CLASS_NAMES_PATH):
        logger.warning(f"类别文件 '{CLASS_NAMES_PATH}' 不存在。预测功能不可用。")
        return
        
    # 4. 加载模型
    try:
        logger.info(f"--- 正在加载激活的模型: {ACTIVE_MODEL} ---")
        with open(CLASS_NAMES_PATH, 'r', encoding='utf-8') as f:
            class_names = json.load(f)
        NUM_CLASSES = len(class_names)
        
        model_instance = model_creator(NUM_CLASSES, use_pretrained=False)
        model_instance.load_state_dict(torch.load(model_path, map_location=DEVICE, weights_only=True))
        model_instance.to(DEVICE)
        model_instance.eval()
        model = model_instance # 赋值给全局变量
        logger.info(f"模型 '{ACTIVE_MODEL}' 加载成功！预测功能已就绪。")
    except Exception as e:
        logger.error(f"加载模型 '{ACTIVE_MODEL}' 时发生错误!", exc_info=True)


# --- 预测函数恢复到简单版本，不再需要 model_name 参数 ---
def predict_herb(input_image: Image.Image):
    """核心预测函数。"""
    if model is None:
        active_model_name = ACTIVE_MODEL # 从配置获取当前激活的模型名称
        return {"error": f"模型 '{active_model_name}' 未能成功加载。请先训练该模型并重启服务。"}

    # ...后续逻辑完全不变...
    if input_image.mode != "RGB":
        input_image = input_image.convert("RGB")
    
    preprocess = data_transforms['predict']
    img_t = preprocess(input_image)
    batch_t = torch.unsqueeze(img_t, 0).to(DEVICE)

    with torch.no_grad():
        out = model(batch_t)

    probabilities = torch.nn.functional.softmax(out, dim=1)[0]
    
    aggregated_confidences = defaultdict(float)
    for i, prob in enumerate(probabilities):
        pinyin_name = class_names[i]
        chinese_name = pinyin_to_chinese.get(pinyin_name, pinyin_name)
        aggregated_confidences[chinese_name] += prob.item()

    sorted_aggregated = sorted(aggregated_confidences.items(), key=lambda x: x[1], reverse=True)
    top_pred_name, top_pred_prob = sorted_aggregated[0]
    
    logger.info(f"使用模型 '{ACTIVE_MODEL}' 识别成功。结果: {top_pred_name} ({top_pred_prob:.2%})")

    result = {
        "top_prediction": top_pred_name,
        "top_confidence": f"{top_pred_prob:.2%}",
        "all_predictions": {name: f"{prob:.1%}" for name, prob in sorted_aggregated[:5]}
    }
    return result