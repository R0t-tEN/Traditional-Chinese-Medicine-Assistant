# herb_project/recognizer/admin.py

from django.contrib import admin
from .models import Herb # 导入我们创建的 Herb 模型

@admin.register(Herb)
class HerbAdmin(admin.ModelAdmin):
    list_display = ('pinyin_name', 'chinese_name') # 在列表页显示的字段
    search_fields = ('pinyin_name', 'chinese_name') # 增加搜索框
    
# 如果你不想用上面的装饰器，也可以用下面这种简单的方式
# admin.site.register(Herb)