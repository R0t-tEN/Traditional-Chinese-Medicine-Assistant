# herb_project/recognizer/views.py

from django.shortcuts import render
from PIL import Image
from .predictor import predict_herb
import base64
from io import BytesIO
from .models import Herb
from django.db.models import Q # 导入 Q 对象，用于实现复杂的查询

def catalog_view(request):
    """
    药材目录视图，现在支持搜索功能。
    """
    # 1. 获取用户通过GET请求提交的搜索关键词
    # request.GET.get('q', '') 表示尝试获取名为 'q' 的参数，如果不存在则返回空字符串
    query = request.GET.get('q', '')
    
    # 2. 根据关键词筛选数据
    if query:
        # 如果有搜索词，就进行筛选
        # 使用 Q 对象实现 OR 查询：在中文名(chinese_name) 或 拼音名(pinyin_name) 中查找
        # __icontains 表示“不区分大小写的包含”
        herbs = Herb.objects.filter(
            Q(chinese_name__icontains=query) | Q(pinyin_name__icontains=query)
        ).order_by('pinyin_name')
    else:
        # 如果没有搜索词，就显示所有药材
        herbs = Herb.objects.all().order_by('pinyin_name')
    
    # 3. 准备要传递给模板的上下文数据
    context = {
        'herbs': herbs,
        'herbs_count': herbs.count(),
        'query': query, # 将搜索词也传递给模板，以便在搜索框中回显
    }
    return render(request, 'recognizer/catalog.html', context)


# recognize_view 保持不变
def recognize_view(request):
    context = {'result': None}
    
    if request.method == 'POST' and request.FILES.get('image'):
        image_file = request.FILES['image']
        try:
            input_image = Image.open(image_file)
            
            prediction_result = predict_herb(input_image)
            context['result'] = prediction_result
            
            buffered = BytesIO()
            save_format = 'PNG' if input_image.mode == 'RGBA' else 'JPEG'
            input_image.save(buffered, format=save_format)
            img_str = base64.b64encode(buffered.getvalue()).decode()
            context['uploaded_image'] = f"data:image/{save_format.lower()};base64,{img_str}"

        except Exception as e:
            context['result'] = {"error": f"处理图片时出错: {e}"}

    return render(request, 'recognizer/recognize.html', context)