import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets
import os
from tqdm import tqdm
import json
import logging

# --- 1. 从配置文件导入所有配置并设置日志 ---
from config import (
    DEVICE, DATA_DIR, NUM_EPOCHS, BATCH_SIZE, LEARNING_RATE,
    MODEL_SAVE_PATH, CLASS_NAMES_PATH, data_transforms, setup_logging
)
from model import create_resnet18_model

# 初始化日志系统
setup_logging()

logging.info(f"Using device: {DEVICE}")

# --- 2. 数据加载 ---
# 使用从config导入的路径和转换
logging.info("正在加载数据集...")
image_datasets = {x: datasets.ImageFolder(os.path.join(DATA_DIR, x), data_transforms[x])
                  for x in ['train', 'val']}
dataloaders = {x: DataLoader(image_datasets[x], batch_size=BATCH_SIZE, shuffle=True, num_workers=4)
               for x in ['train', 'val']}
dataset_sizes = {x: len(image_datasets[x]) for x in ['train', 'val']}
logging.info("数据集加载完成。")

# --- 3. 获取并保存类别名称 (关键步骤) ---
class_names = image_datasets['train'].classes
num_classes = len(class_names)
# 将类别列表保存到json文件，供app.py使用
with open(CLASS_NAMES_PATH, 'w') as f:
    json.dump(class_names, f)
logging.info(f"识别的类别共 {num_classes} 种, 已保存至 {CLASS_NAMES_PATH}")
logging.info(f"训练集图片数量: {dataset_sizes['train']}, 验证集图片数量: {dataset_sizes['val']}")


# --- 4. 定义模型、损失函数和优化器 ---
# 从model.py创建模型
logging.info("正在创建ResNet-18模型...")
model = create_resnet18_model(num_classes, use_pretrained=True)
model = model.to(DEVICE)
logging.info("模型创建成功并已移动到设备 %s。", DEVICE)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

# --- 5. 训练和验证循环 ---
def train_model(model, criterion, optimizer, num_epochs=25):
    logging.info("开始模型训练...")
    for epoch in range(num_epochs):
        logging.info(f'Epoch {epoch+1}/{num_epochs}')
        logging.info('-' * 20)

        # 每个epoch都有一个训练和验证阶段
        for phase in ['train', 'val']:
            if phase == 'train':
                model.train()  # 设置模型为训练模式
            else:
                model.eval()   # 设置模型为评估模式

            running_loss = 0.0
            running_corrects = 0

            # 使用tqdm创建进度条
            progress_bar = tqdm(dataloaders[phase], desc=f'{phase.capitalize()} Epoch {epoch+1}')

            # 遍历数据
            for inputs, labels in progress_bar:
                inputs = inputs.to(DEVICE)
                labels = labels.to(DEVICE)

                # 梯度清零
                optimizer.zero_grad()

                # 前向传播
                with torch.set_grad_enabled(phase == 'train'):
                    outputs = model(inputs)
                    _, preds = torch.max(outputs, 1)
                    loss = criterion(outputs, labels)

                    # 后向传播 + 仅在训练阶段进行优化
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()

                # 统计损失和准确率
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)
                
                # 更新tqdm进度条的后缀信息
                progress_bar.set_postfix(loss=loss.item(), acc=torch.sum(preds == labels.data).item() / inputs.size(0))


            epoch_loss = running_loss / dataset_sizes[phase]
            epoch_acc = running_corrects.double() / dataset_sizes[phase]

            logging.info(f'{phase.upper()} - Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')

    logging.info("模型训练完成。")
    return model



# --- 6. 开始训练和保存 ---
if __name__ == '__main__':
    model_trained = train_model(model, criterion, optimizer, num_epochs=NUM_EPOCHS)
    
    logging.info("正在保存模型权重...")
    torch.save(model_trained.state_dict(), MODEL_SAVE_PATH)
    logging.info(f"模型已成功保存为 {MODEL_SAVE_PATH}")