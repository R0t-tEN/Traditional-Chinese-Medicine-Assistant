# herb_project/recognizer/views.py

from django.shortcuts import render
from PIL import Image
from .predictor import predict_herb
import base64
from io import BytesIO
from .models import Herb # 导入 Herb 模型

# 新增的目录视图
def catalog_view(request):
    herbs = Herb.objects.all().order_by('pinyin_name') # 获取所有药材数据并排序
    context = {
        'herbs': herbs,
        'herbs_count': herbs.count(),
    }
    return render(request, 'recognizer/catalog.html', context)

# 修改后的识别视图 (逻辑不变，只是作为独立页面)
def recognize_view(request):
    context = {'result': None}
    
    if request.method == 'POST' and request.FILES.get('image'):
        image_file = request.FILES['image']
        try:
            input_image = Image.open(image_file)
            
            prediction_result = predict_herb(input_image)
            context['result'] = prediction_result
            
            buffered = BytesIO()
            save_format = 'PNG' if input_image.mode == 'RGBA' else 'JPEG'
            input_image.save(buffered, format=save_format)
            img_str = base64.b64encode(buffered.getvalue()).decode()
            context['uploaded_image'] = f"data:image/{save_format.lower()};base64,{img_str}"

        except Exception as e:
            context['result'] = {"error": f"处理图片时出错: {e}"}

    return render(request, 'recognizer/recognize.html', context)