现在默认使用的是ResNet-18
model.py中已经添加了DenseNet-121，按照如下操作修改即可


修改 train.py:
更改 from model import ... 这一行。
更改 model = create... 这一行。
# train.py (部分修改)

# --- 1. 从配置文件导入所有配置 ---
# ...
# 从 model.py 导入我们新的模型创建函数
from model import create_densenet121_model # <--- 修改这里

# ...

# --- 4. 定义模型、损失函数和优化器 ---
# 使用新函数创建模型
model = create_densenet121_model(num_classes, use_pretrained=True) # <--- 修改这里
model = model.to(DEVICE)

# ... (其余代码不变)



修改 app.py:
同样，更改 from model import ... 和 model = create... 这两行。
# app.py (部分修改)

# 2
from config import DEVICE, MODEL_SAVE_PATH, CLASS_NAMES_PATH, pinyin_to_chinese, data_transforms
# 从 model.py 导入我们新的模型创建函数
from model import create_densenet121_model # <--- 修改这里

# ...

# 2
model = None
if NUM_CLASSES > 0:
    # 创建模型结构，注意 use_pretrained=False
    model = create_densenet121_model(NUM_CLASSES, use_pretrained=False) # <--- 修改这里
    try:
        # ... (其余代码不变)


# 3
重新训练模型
这是最后也是最关键的一步。因为你已经更换了模型的“骨架”，之前用 ResNet-18 训练出的权重文件 t_out_model.pth 已经完全不兼容了。
（可选）删除旧的模型文件：为了避免混淆，可以手动删除 t_out_model.pth 文件。
运行训练脚本：
python train.py
