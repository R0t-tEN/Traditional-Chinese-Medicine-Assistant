import torch
from torchvision import transforms
import logging
import sys

# --- 0. 日志配置 ---
LOG_FILE = 'herb_recognizer.log'

def setup_logging(log_level=logging.INFO):
    """配置全局日志记录器"""
    # 获取根日志记录器
    logger = logging.getLogger()
    
    # 防止重复添加handlers
    if logger.hasHandlers():
        logger.handlers.clear()
        
    logger.setLevel(log_level)
    
    # 定义日志格式
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # 创建并添加控制台处理器
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setFormatter(formatter)
    logger.addHandler(stdout_handler)
    
    # 创建并添加文件处理器
    file_handler = logging.FileHandler(LOG_FILE, mode='a', encoding='utf-8')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    logging.info("日志系统已配置完成，将同时输出到控制台和文件 '%s'", LOG_FILE)

# --- 1. 设备配置 ---
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# --- 2. 路径配置 ---
DATA_DIR = './dataset'
MODEL_SAVE_PATH = 't_out_model.pth' # 统一模型保存路径
CLASS_NAMES_PATH = 'class_names.json'      # 保存类别索引的文件路径

# --- 3. 训练超参数 ---
NUM_EPOCHS = 25
BATCH_SIZE = 16
LEARNING_RATE = 0.001

# --- 4. 数据转换 ---
data_transforms = {
    'train': transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
    'val': transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
    'predict': transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])
}


# --- 5. 类别名称映射 ---
pinyin_to_chinese = {
    "aiye": "艾叶", "ajiao": "阿胶", "baibiandou": "白扁豆", "baibu": "百部", "baifan": "白矾",
    "baihe": "百合", "baihuasheshecao": "白花蛇舌草", "baikou": "白蔻", "baimaogen": "白茅根",
    "baishao": "白芍", "baitouweng": "白头翁", "baizhu": "白术", "baiziren": "柏子仁",
    "bajitian": "巴戟天", "banlangen": "板蓝根", "banxia": "半夏", "beishashenkuai": "北沙参",
    "beishashentiao": "北沙参", "biejia": "鳖甲", "cangzhu": "苍术", "caoguo": "草果",
    "caokou": "草豆蔻", "cebaiye": "侧柏叶", "chaihu": "柴胡", "chantui": "蝉蜕",
    "chenpi": "陈皮", "chenxiang": "沉香", "chishao": "赤芍", "chishizhi": "赤石脂",
    "chongcao": "虫草", "chuanshanjia": "穿山甲", "chuanxinlian": "穿心莲", "cishi": "磁石",
    "dafupi": "大腹皮", "dangshen": "党参", "danshen": "丹参", "daqingye": "大青叶",
    "daxueteng": "大血藤", "digupi": "地骨皮", "dilong": "地龙", "diyu": "地榆",
    "duzhong": "杜仲", "fangfeng": "防风", "foshou": "佛手", "fuling": "茯苓", "fupenzi": "覆盆子",
    "fuzi": "附子", "gancao": "甘草", "ganjiang": "干姜", "gegen": "葛根", "gouqizi": "枸杞子",
    "gouteng": "钩藤", "guanzhong": "贯众", "guya": "谷芽", "hehuanpi": "合欢皮",
    "heshouwu": "何首乌", "honghua": "红花", "hongkou": "红豆蔻", "houpu": "厚朴", "huaihua": "槐花",
    "huangbo": "黄柏", "huangjing": "黄精", "huangqin": "黄芩", "huomaren": "火麻仁",
    "huzhang": "虎杖", "jiangcan": "僵蚕", "jianghuang": "姜黄", "jineijin": "鸡内金",
    "jingjie": "荆芥", "jinqiancao": "金钱草", "jinyinhua": "金银花", "jixueteng": "鸡血藤",
    "juemingzi": "决明子", "kushen": "苦参", "laifuzi": "莱菔子", "lianqiao": "连翘",
    "lianzixin": "莲子心", "lingzhi": "灵芝", "lizhihe": "荔枝核", "longgu": "龙骨",
    "lulutong": "路路通", "luohanguo": "罗汉果", "luoshiteng": "络石藤", "maidong": "麦冬",
    "maiya": "麦芽", "mohanlian": "墨旱莲", "mudanpi": "牡丹皮", "muli": "牡蛎",
    "muxiang": "木香", "niuxi": "牛膝", "nvzhenzi": "女贞子", "paojiang": "炮姜",
    "peilan": "佩兰", "pugongying": "蒲公英", "puhuang": "蒲黄", "qianghuo": "羌活",
    "qianhu": "前胡", "qinghao": "青蒿", "quanxie": "全蝎", "renshen": "人参",
    "renshenqiepian": "人参切片", "roucongronggen": "肉苁蓉", "roucongrongpian": "肉苁蓉",
    "roudoukou": "肉豆蔻", "rougui": "肉桂", "sangpiaoxiao": "桑螵蛸", "sangshen": "桑葚",
    "sanqi": "三七", "shanyao": "山药", "shanzha": "山楂", "shanzhuyu": "山茱萸",
    "sharen": "砂仁", "shechuangzi": "蛇床子", "shegan": "射干", "shengma": "升麻",
    "shenqu": "神曲", "shichangpu": "石菖蒲", "shigao": "石膏", "shihu": "石斛",
    "shouwutengkuai": "首乌藤", "shouwutengpian": "首乌藤", "shuihonghuazi": "水红花子",
    "shuiniujiao": "水牛角", "suanzaoren": "酸枣仁", "taoren": "桃仁", "tiandong": "天冬",
    "tiankuizi": "天葵子", "tianmakuai": "天麻", "tianmapian": "天麻", "tiannanxing": "天南星",
    "tongcao": "通草", "tubiechong": "土鳖虫", "tusizi": "菟丝子", "wujiapi": "五加皮",
    "wulingzhi": "五灵脂", "wumei": "乌梅", "wuweizi": "五味子", "xiakucao": "夏枯草",
    "xiangfu": "香附", "xianhecao": "仙鹤草", "xiaohuixiang": "小茴香", "xinyi": "辛夷",
    "xixin": "细辛", "xuduan": "续断", "yejuhua": "野菊花", "yimucao": "益母草",
    "yinchen": "茵陈", "yiyiren": "薏苡仁", "yuanzhi": "远志", "yujin": "郁金",
    "yuzhupian": "玉竹", "yuzhutiao": "玉竹", "zelan": "泽兰", "zhebeimu": "浙贝母",
    "zhenzhumu": "珍珠母", "zhimu": "知母", "zhiqiaopian": "枳壳", "zhiqiaotiao": "枳壳",
    "zhishi": "枳实", "zhuru": "竹茹", "zicao": "紫草", "zihuadiding": "紫花地丁","ziyuan":"紫菀"
}