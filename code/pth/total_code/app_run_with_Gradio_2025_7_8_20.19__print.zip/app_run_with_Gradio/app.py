# app.py

import torch
import gradio as gr
from PIL import Image
from collections import defaultdict
import os
import json

# --- 1. 从配置文件导入 ---
from config import DEVICE, MODEL_SAVE_PATH, CLASS_NAMES_PATH, pinyin_to_chinese, data_transforms
from model import create_resnet18_model

# --- 2. 动态加载类别名称 (关键改动) ---
try:
    with open(CLASS_NAMES_PATH, 'r') as f:
        class_names = json.load(f)
    NUM_CLASSES = len(class_names)
    print(f"成功从 {CLASS_NAMES_PATH} 加载 {NUM_CLASSES} 个类别。")
except FileNotFoundError:
    print(f"错误: 找不到类别文件 '{CLASS_NAMES_PATH}'。请先运行 train.py 生成该文件。")
    class_names = []
    NUM_CLASSES = 0

# --- 3. 模型加载 ---
model = None
if NUM_CLASSES > 0:
    # 创建模型结构，注意 use_pretrained=False，因为我们要加载自己的权重
    model = create_resnet18_model(NUM_CLASSES, use_pretrained=False)
    try:
        print(f"正在从'{MODEL_SAVE_PATH}'加载模型...")
        model.load_state_dict(torch.load(MODEL_SAVE_PATH, map_location=DEVICE))
        model.to(DEVICE)
        model.eval()
        print("模型加载成功！")
    except FileNotFoundError:
        print(f"错误: 找不到模型文件 '{MODEL_SAVE_PATH}'。请先运行 train.py 训练并保存模型。")
        model = None
    except Exception as e:
        print(f"加载模型时发生严重错误: {e}")
        model = None

# --- 4. 核心预测函数 (逻辑不变，使用config中的数据) ---
def predict_herb(input_image):
    if model is None:
        return None, "错误：模型未能成功加载，无法进行识别。请检查启动时的报错信息。"
    if input_image is None:
        return None, "请先上传一张图片再点击识别按钮。"

    # 使用config中定义的'predict'转换
    preprocess = data_transforms['predict']
    img_t = preprocess(input_image)
    batch_t = torch.unsqueeze(img_t, 0).to(DEVICE)
    
    with torch.no_grad():
        out = model(batch_t)
    
    probabilities = torch.nn.functional.softmax(out, dim=1)[0]
    
    aggregated_confidences = defaultdict(float)
    for i, prob in enumerate(probabilities):
        pinyin_name = class_names[i]
        chinese_name = pinyin_to_chinese.get(pinyin_name, pinyin_name)
        aggregated_confidences[chinese_name] += prob.item()

    if not aggregated_confidences:
         return None, "识别失败，无法计算置信度。"

    top_pred_name = max(aggregated_confidences, key=aggregated_confidences.get)
    top_pred_prob = aggregated_confidences[top_pred_name]
    
    result_text = f"识别结果: {top_pred_name}\n置信度: {top_pred_prob:.2%}"
    
    return aggregated_confidences, result_text


# --- 5. Gradio 界面 (完全不变) ---
# ...
# (将您原始app.py中的Gradio界面代码完整粘贴到这里即可)
with gr.Blocks(theme=gr.themes.Soft(), title="中草药识别器") as iface:
    gr.Markdown("# 智能中草药识别器")
    gr.Markdown("上传一张中草药的图片，AI会尝试识别它的种类。")
    with gr.Row():
        with gr.Column(scale=1):
            image_input = gr.Image(type="pil", label="上传药材图片")
            submit_btn = gr.Button("开始识别", variant="primary")
        with gr.Column(scale=1):
            prob_output = gr.Label(num_top_classes=5, label="识别概率 (Top 5)")
            text_output = gr.Textbox(label="识别结果")
    submit_btn.click(fn=predict_herb, inputs=image_input, outputs=[prob_output, text_output])
    example_list = []
    if os.path.isdir("examples"): example_list = [os.path.join("examples", f) for f in os.listdir("examples")]
    if example_list:
        gr.Examples(examples=example_list, inputs=image_input, outputs=[prob_output, text_output], fn=predict_herb, cache_examples=True)


# --- 6. 启动应用 ---
if __name__ == '__main__':
    if model:
        print("正在启动Gradio Web界面...")
        iface.launch(share=True)
    else:
        print("\n由于模型加载失败，Gradio应用无法启动。")