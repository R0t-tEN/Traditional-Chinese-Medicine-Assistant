# herb_project/recognizer/predictor.py

import torch
from PIL import Image
from collections import defaultdict
import json
import sys
import os

# 获取 Django 项目的根目录 (herb_project/)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# 将 ml_assets 目录添加到 Python 搜索路径中
sys.path.append(os.path.join(BASE_DIR, 'ml_assets'))

# 现在可以安全地从 ml_assets 中导入了
from config import DEVICE, MODEL_SAVE_PATH, CLASS_NAMES_PATH, pinyin_to_chinese, data_transforms
from model import create_resnet18_model

# --- 全局变量，用于缓存加载好的模型 ---
model = None
class_names = []

def load_model():
    """在 Django 启动时调用此函数一次，将模型加载到内存中"""
    global model, class_names

    if model is not None:
        print("模型已经加载，跳过。")
        return

    try:
        with open(CLASS_NAMES_PATH, 'r', encoding='utf-8') as f:
            class_names = json.load(f)
        NUM_CLASSES = len(class_names)
        print(f"成功加载 {NUM_CLASSES} 个类别。")

        model_instance = create_resnet18_model(NUM_CLASSES, use_pretrained=False)
        print(f"正在从 '{MODEL_SAVE_PATH}' 加载模型...")
        model_instance.load_state_dict(torch.load(MODEL_SAVE_PATH, map_location=DEVICE,weights_only=True))
        model_instance.to(DEVICE)
        model_instance.eval()
        model = model_instance # 赋值给全局变量
        print("模型加载成功！")
    except Exception as e:
        print(f"加载模型时发生严重错误: {e}")
        model = None

def predict_herb(input_image: Image.Image):
    """核心预测函数"""
    if model is None:
        return {"error": "模型未能成功加载，无法进行识别。"}

    if input_image.mode != "RGB":
        input_image = input_image.convert("RGB")

    preprocess = data_transforms['predict']
    img_t = preprocess(input_image)
    batch_t = torch.unsqueeze(img_t, 0).to(DEVICE)

    with torch.no_grad():
        out = model(batch_t)

    probabilities = torch.nn.functional.softmax(out, dim=1)[0]

    aggregated_confidences = defaultdict(float)
    for i, prob in enumerate(probabilities):
        pinyin_name = class_names[i]
        chinese_name = pinyin_to_chinese.get(pinyin_name, pinyin_name)
        aggregated_confidences[chinese_name] += prob.item()
    
    if not aggregated_confidences:
         return {"error": "识别失败，无法计算置信度。"}

    sorted_aggregated = sorted(aggregated_confidences.items(), key=lambda x: x[1], reverse=True)
    top_pred_name, top_pred_prob = sorted_aggregated[0]

    # 返回一个结构化的字典，方便前端使用
    result = {
        "top_prediction": top_pred_name,
        "top_confidence": f"{top_pred_prob:.2%}",
        "all_predictions": {name: f"{prob:.1%}" for name, prob in sorted_aggregated[:5]}
    }
    return result