# herb_project/recognizer/views.py
from django.shortcuts import render
from PIL import Image
from .predictor import predict_herb
import base64
from io import BytesIO

def recognize_view(request):
    context = {}
    if request.method == 'POST' and request.FILES.get('image'):
        image_file = request.FILES['image']
        try:
            input_image = Image.open(image_file)
            
            # 调用预测函数
            prediction_result = predict_herb(input_image)
            context['result'] = prediction_result
            
            # 将上传的图片传回前端显示
            buffered = BytesIO()
            # 确保保存为 Web 友好的格式
            save_format = 'PNG' if input_image.mode == 'RGBA' else 'JPEG'
            input_image.save(buffered, format=save_format)
            img_str = base64.b64encode(buffered.getvalue()).decode()
            context['uploaded_image'] = f"data:image/{save_format.lower()};base64,{img_str}"

        except Exception as e:
            context['result'] = {"error": f"处理图片时出错: {e}"}

    return render(request, 'recognizer/recognize.html', context)