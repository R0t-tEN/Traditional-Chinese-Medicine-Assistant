需要在下面位置补上训练好的pth文件
"C:\Users\Lenovo\Desktop\temp\zips_file\app_run_with_Django\herb_project\ml_assets\YOUR PTH"

程序运行方式：在 herb_project 目录下（即能看到 manage.py 文件的目录），运行：python manage.py migrate
