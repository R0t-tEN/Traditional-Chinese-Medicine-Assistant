# herb_project/recognizer/apps.py
from django.apps import AppConfig

class RecognizerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'recognizer'

    def ready(self):
        # Django 服务启动时，会自动执行这里的代码
        from . import predictor
        print("正在初始化PyTorch模型...")
        predictor.load_model()