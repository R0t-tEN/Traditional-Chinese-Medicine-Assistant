# herb_project/recognizer/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # 将根URL (http://.../) 指向我们的识别视图
    path('', views.recognize_view, name='recognize_home'),
]