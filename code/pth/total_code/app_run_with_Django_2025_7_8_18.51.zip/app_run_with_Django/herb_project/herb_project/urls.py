# herb_project/herb_project/urls.py
from django.contrib import admin
from django.urls import path, include # 确保 include 已导入

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('recognizer.urls')), # <-- 添加这行，将根URL请求转发给recognizer应用处理
]