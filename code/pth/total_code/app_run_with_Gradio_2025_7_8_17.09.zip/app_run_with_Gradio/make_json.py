#  make_json.py

import os
import json
from config import DATA_DIR, CLASS_NAMES_PATH # 从我们的配置文件导入路径

def create_class_json():
    """
    根据数据集的 'train' 文件夹，生成 class_names.json 文件。
    """
    train_path = os.path.join(DATA_DIR, 'train')
    
    if not os.path.isdir(train_path):
        print(f"错误: 找不到训练数据路径 '{train_path}'。请确保你的数据集文件夹结构正确。")
        return

    # os.listdir() 返回的列表顺序在不同系统上可能不同，所以我们必须排序！
    # ImageFolder在内部也是按字母顺序排列文件夹来确定类别索引的。
    class_names = sorted([d.name for d in os.scandir(train_path) if d.is_dir()])
    
    if not class_names:
        print(f"错误: 在 '{train_path}' 中没有找到任何类别子文件夹。")
        return
        
    try:
        with open(CLASS_NAMES_PATH, 'w', encoding='utf-8') as f:
            json.dump(class_names, f, ensure_ascii=False, indent=4)
        print(f"成功！已根据文件夹顺序生成 '{CLASS_NAMES_PATH}'。")
        print(f"共找到 {len(class_names)} 个类别。")
        print("前5个类别是:", class_names[:5])

    except Exception as e:
        print(f"写入文件时发生错误: {e}")

if __name__ == '__main__':
    create_class_json()