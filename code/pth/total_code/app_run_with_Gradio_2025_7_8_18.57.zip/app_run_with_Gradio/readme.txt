需要在这个文件夹内补充训练好的pth文件

运行方式：在app_run with Gradio目录下，运行：python app.py
