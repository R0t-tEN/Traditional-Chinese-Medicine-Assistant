

使用方法：

第一步：完善你的文件夹结构
你需要手动创建dataset文件夹，并把你的训练和验证图片放进去。完整的结构应该如下所示：
total_code/
├── dataset/          <-- 1. 你需要【手动创建】这个文件夹
│   ├── train/        <-- 训练图片放这里
│   │   ├── aiyue/      (艾叶类别的所有图片)
│   │   ├── ajiao/      (阿胶类别的所有图片)
│   │   └── ...         (其他所有类别的文件夹)
│   └── val/          <-- 验证图片放这里
│       ├── aiyue/
│       ├── ajiao/
│       └── ...
│
├── app.py
├── config.py
├── model.py
├── requirements.txt
└── train.py
dataset/train 和 dataset/val 里面的子文件夹名称就是你的中草药类别的拼音，这必须和你 config.py 文件里的 pinyin_to_chinese 字典的键（key）对应起来。
train.py 会自动根据 dataset/train 里的文件夹名生成类别列表。




第二步（推荐）：创建并激活虚拟环境
这可以避免和你电脑上其他Python项目的库产生冲突。

# 创建一个名为 venv 的虚拟环境
python -m venv venv

# 激活环境
# 如果你是 Windows系统:
venv\Scripts\activate
# 如果你是 macOS 或 Linux系统:
source venv/bin/activate
激活成功后，你的终端提示符前面会出现 (venv) 字样。

第三步：安装所有必需的库
项目中的 requirements.txt 文件已经列出了所有依赖。
它会自动安装 torch, torchvision, gradio, tqdm 等所有需要的库。



这里推荐使用Anaconda Prompt 设置环境和安装依赖
创建一个新的环境：我们给它起个名字，比如 tcm_env（中草药环境），并指定一个Python版本（推荐使用3.8, 3.9或3.10）。
conda create --name tcm_env python=3.9
终端会询问你是否继续 (y/n)?，输入 y 然后按回车。

激活这个新环境：
conda activate tcm_env
激活成功后，你会看到终端命令提示符的最前面，从 (base) 变成了 (tcm_env)。这表示你现在所有的操作都将在这个独立、干净的环境中进行。

现在你的 tcm_env 环境已经激活，它有自己独立的 pip。我们可以用和之前完全一样的命令来安装依赖。
首先使用 cd total_code的存放路径\total_code
例如: cd Desktop\total_code
之后
pip install -r requirements.txt





第二步：训练模型
现在一切准备就绪，可以开始训练了。
在你的终端（确保你还在 total_code 目录下并且虚拟环境已激活），运行以下命令：
python train.py

你会看到什么：
首先，程序会打印出设备信息（CPU或GPU）、类别总数、训练集和验证集的图片数量。
接着，训练会开始，你会看到一个由 tqdm 生成的进度条，实时显示每个Epoch的训练进度、损失（loss）和准确率（acc）。
Generated code
Train Epoch 1: 100%|██████████| 125/125 [00:50<00:00,  2.48it/s, loss=0.85, acc=0.75]
train Loss: 1.5031 Acc: 0.6120

Val Epoch 1: 100%|██████████| 32/32 [00:10<00:00,  3.10it/s, loss=0.65, acc=0.81]
val Loss: 0.9876 Acc: 0.7850
训练将持续进行 config.py 中设定的 NUM_EPOCHS 轮。


训练将持续进行 config.py 中设定的 NUM_EPOCHS 轮。
训练完成后，会自动在 total_code 文件夹下生成两个新文件：
t_out_model.pth: 这是你训练好的模型权重文件。
class_names.json: 这是一个包含了所有类别名称（拼音）的列表文件，确保了app.py在推理时使用的类别和训练时完全一致。



第三步：启动并使用Web应用
当模型训练完成，并且你看到了 t2.pth 和 class_names.json 这两个文件后，就可以启动你的识别应用了。
在同一个终端里，运行以下命令：
python app.py

你会看到什么：
程序会先打印加载模型和类别的日志信息。
然后，Gradio会启动一个Web服务器，并显示两个URL地址：
Generated code
Running on local URL:  http://127.0.0.1:7860
Running on public URL: https://xxxxxxxxxx.gradio.live
Local URL: 只能在你自己的电脑上访问。
Public URL: 这是一个临时生成的公共链接，你可以把它分享给朋友，他们在任何地方都能通过这个链接访问你的应用（链接在72小时后失效）。
如何使用：
复制任意一个URL地址，用你的浏览器（如Chrome, Edge）打开它。
你将看到一个简洁的网页界面，上面有“上传药材图片”的区域。
点击上传区域，选择一张你要识别的中草药图片。
点击“开始识别”按钮。
稍等片刻，右侧的“识别结果”和“识别概率”框中就会显示出AI的预测结果。


如果已经有训练好的的.pth模型，请将其命名为t_out_model.pth
在同一个终端中，运行
python make_json.py
这样可以直接获取class_names.json，而不用再进行train